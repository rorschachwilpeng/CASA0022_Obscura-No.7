#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Raspberry Pi Hardware Interface
树莓派真实硬件接口 - 替代模拟器
"""

import time
import logging
from typing import Dict, Optional, Tuple

# 尝试导入树莓派专用库
try:
    import RPi.GPIO as GPIO
    from gpiozero import RotaryEncoder, Button
    import spidev
    import smbus
    PI_HARDWARE_AVAILABLE = True
except ImportError:
    PI_HARDWARE_AVAILABLE = False
    print("⚠️ Raspberry Pi hardware libraries not available - using simulation mode")

class RaspberryPiHardware:
    """树莓派硬件接口类"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.hardware_available = PI_HARDWARE_AVAILABLE
        
        # 硬件引脚配置
        self.encoder_pin_a = config.get('hardware.encoder.pin_a', 2)
        self.encoder_pin_b = config.get('hardware.encoder.pin_b', 3)
        self.button_pin = config.get('hardware.button.pin', 4)
        self.i2c_bus = config.get('hardware.i2c.bus', 1)
        self.compass_address = config.get('hardware.compass.i2c_address', 0x0D)
        
        # 初始化硬件
        if self.hardware_available:
            self._init_hardware()
        else:
            self._init_simulation()
    
    def _init_hardware(self):
        """初始化真实硬件"""
        try:
            # 初始化编码器（距离测量）
            self.encoder = RotaryEncoder(self.encoder_pin_a, self.encoder_pin_b)
            self.encoder_position = 0
            self.encoder.when_rotated_clockwise = self._encoder_clockwise
            self.encoder.when_rotated_counter_clockwise = self._encoder_counter_clockwise
            
            # 初始化按钮（确认输入）
            self.button = Button(self.button_pin)
            self.button_pressed = False
            self.button.when_pressed = self._button_press
            
            # 初始化I2C总线（磁感器）
            self.i2c = smbus.SMBus(self.i2c_bus)
            
            self.logger.info("🔧 Raspberry Pi hardware initialized successfully")
            
        except Exception as e:
            self.logger.error(f"❌ Hardware initialization failed: {e}")
            self.hardware_available = False
            self._init_simulation()
    
    def _init_simulation(self):
        """初始化模拟模式"""
        self.encoder_position = 0
        self.button_pressed = False
        self.logger.warning("⚠️ Running in simulation mode - no real hardware")
    
    def _encoder_clockwise(self):
        """编码器顺时针回调"""
        self.encoder_position += 1
        
    def _encoder_counter_clockwise(self):
        """编码器逆时针回调"""
        self.encoder_position -= 1
    
    def _button_press(self):
        """按钮按下回调"""
        self.button_pressed = True
    
    def read_distance_input(self, timeout: float = 30.0) -> float:
        """
        读取距离输入（通过编码器）
        
        Args:
            timeout: 超时时间（秒）
        
        Returns:
            distance: 距离值（公里）
        """
        if not self.hardware_available:
            # 模拟模式 - 使用键盘输入
            try:
                distance_str = input("🎯 输入目标距离 (km): ").strip()
                return float(distance_str)
            except ValueError:
                return 5.0  # 默认值
        
        print("🎯 请转动编码器设置距离，按按钮确认...")
        print("   编码器每一步 = 0.1 km")
        
        self.encoder_position = 50  # 初始位置对应5km
        self.button_pressed = False
        
        start_time = time.time()
        
        while not self.button_pressed and (time.time() - start_time) < timeout:
            # 显示当前距离
            current_distance = self.encoder_position * 0.1
            print(f"\r📏 当前距离: {current_distance:.1f} km", end="", flush=True)
            time.sleep(0.1)
        
        if self.button_pressed:
            distance = self.encoder_position * 0.1
            print(f"\n✅ 距离设置: {distance:.1f} km")
            return distance
        else:
            print(f"\n⏰ 超时，使用默认距离: 5.0 km")
            return 5.0
    
    def read_compass_direction(self) -> float:
        """
        读取磁感器方向数据
        
        Returns:
            direction: 方向角度（0-360度）
        """
        if not self.hardware_available:
            # 模拟模式
            import random
            direction = random.uniform(0, 360)
            print(f"🧭 模拟磁感器读数: {direction:.1f}°")
            return direction
        
        try:
            # 读取HMC5883L磁感器数据
            # 这里需要根据具体的磁感器型号调整寄存器地址
            
            # 配置寄存器
            self.i2c.write_byte_data(self.compass_address, 0x00, 0x70)  # 配置寄存器A
            self.i2c.write_byte_data(self.compass_address, 0x01, 0xA0)  # 配置寄存器B
            self.i2c.write_byte_data(self.compass_address, 0x02, 0x00)  # 模式寄存器
            
            time.sleep(0.1)
            
            # 读取X、Y、Z轴数据
            data = self.i2c.read_i2c_block_data(self.compass_address, 0x03, 6)
            
            # 转换为有符号整数
            x = self._bytes_to_int(data[0], data[1])
            y = self._bytes_to_int(data[4], data[5])
            z = self._bytes_to_int(data[2], data[3])
            
            # 计算方向角
            import math
            direction = math.atan2(y, x) * 180 / math.pi
            if direction < 0:
                direction += 360
            
            self.logger.info(f"🧭 磁感器读数: {direction:.1f}° (X:{x}, Y:{y}, Z:{z})")
            return direction
            
        except Exception as e:
            self.logger.error(f"❌ 磁感器读取失败: {e}")
            # 返回模拟值
            import random
            return random.uniform(0, 360)
    
    def _bytes_to_int(self, high_byte: int, low_byte: int) -> int:
        """将两个字节转换为有符号整数"""
        value = (high_byte << 8) + low_byte
        if value >= 32768:
            value = value - 65536
        return value
    
    def read_time_offset_input(self, timeout: float = 30.0) -> float:
        """
        读取时间偏移输入
        
        Args:
            timeout: 超时时间（秒）
        
        Returns:
            time_offset: 时间偏移（年）
        """
        if not self.hardware_available:
            # 模拟模式 - 使用键盘输入
            try:
                time_str = input("⏰ 输入时间偏移 (年): ").strip()
                return float(time_str)
            except ValueError:
                return 5.0  # 默认值
        
        # 真实硬件模式 - 可以用编码器或其他方式
        print("⏰ 请设置时间偏移...")
        try:
            time_offset = float(input("输入年数: "))
            return time_offset
        except:
            return 5.0
    
    def get_hardware_status(self) -> Dict:
        """获取硬件状态"""
        status = {
            'hardware_available': self.hardware_available,
            'encoder_available': False,
            'compass_available': False,
            'button_available': False
        }
        
        if self.hardware_available:
            try:
                # 测试编码器
                status['encoder_available'] = hasattr(self, 'encoder')
                
                # 测试磁感器
                self.i2c.read_byte(self.compass_address)
                status['compass_available'] = True
                
                # 测试按钮
                status['button_available'] = hasattr(self, 'button')
                
            except Exception as e:
                self.logger.warning(f"⚠️ Hardware status check failed: {e}")
        
        return status
    
    def cleanup(self):
        """清理硬件资源"""
        if self.hardware_available:
            try:
                if hasattr(self, 'encoder'):
                    self.encoder.close()
                if hasattr(self, 'button'):
                    self.button.close()
                if hasattr(self, 'i2c'):
                    self.i2c.close()
                GPIO.cleanup()
                self.logger.info("🔧 Hardware cleanup completed")
            except Exception as e:
                self.logger.error(f"❌ Hardware cleanup failed: {e}")

if __name__ == "__main__":
    # 测试硬件接口
    print("🔧 Testing Raspberry Pi Hardware Interface...")
    
    config = {
        'hardware': {
            'encoder': {'pin_a': 2, 'pin_b': 3},
            'button': {'pin': 4},
            'i2c': {'bus': 1},
            'compass': {'i2c_address': 0x0D}
        }
    }
    
    hardware = RaspberryPiHardware(config)
    
    # 显示硬件状态
    status = hardware.get_hardware_status()
    print("📊 Hardware Status:")
    for key, value in status.items():
        print(f"   {key}: {'✅' if value else '❌'}")
    
    # 测试读取功能
    try:
        distance = hardware.read_distance_input(timeout=10)
        print(f"📏 Distance: {distance:.1f} km")
        
        direction = hardware.read_compass_direction()
        print(f"🧭 Direction: {direction:.1f}°")
        
        time_offset = hardware.read_time_offset_input(timeout=10)
        print(f"⏰ Time offset: {time_offset:.1f} years")
        
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted by user")
    finally:
        hardware.cleanup()
        print("�� Test completed") 