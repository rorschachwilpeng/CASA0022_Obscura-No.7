#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试Prompt模板集成
验证新的图像生成prompt模板功能是否正确集成到工作流中
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config_manager import ConfigManager
from core.cloud_api_client import CloudAPIClient
from core.image_prompt_builder import ImagePromptBuilder

def test_prompt_builder_standalone():
    """测试独立的prompt构建器"""
    print("🧪 测试1: 独立Prompt构建器")
    print("-" * 40)
    
    # 创建prompt构建器
    builder = ImagePromptBuilder()
    
    # 模拟数据
    weather_data = {
        'current_weather': {
            'temperature': 22,
            'humidity': 70,
            'pressure': 1012,
            'wind_speed': 4.2,
            'weather_main': 'Clouds',
            'weather_description': 'scattered clouds'
        }
    }
    
    location_info = {
        'latitude': 51.5074,
        'longitude': -0.1278,
        'map_info': {
            'location_info': 'Westminster, London, UK',
            'location_details': {
                'locality': 'Westminster',
                'country': 'United Kingdom'
            }
        }
    }
    
    prediction_data = {
        'predicted_temperature': 19.5,
        'predicted_weather_condition': 'partly cloudy',
        'confidence': 0.85
    }
    
    # 测试不同风格
    styles = ['realistic', 'artistic']
    for style in styles:
        print(f"\n🎨 {style.title()} Style:")
        prompt = builder.build_comprehensive_prompt(
            weather_data=weather_data,
            location_info=location_info,
            prediction_data=prediction_data,
            style_preference=style
        )
        print(f"长度: {len(prompt)} 字符")
        print(f"Preview: {prompt[:200]}...")
    
    print("\n✅ 独立prompt构建器测试完成")

def test_cloud_api_client_integration():
    """测试云端API客户端集成"""
    print("\n🧪 测试2: 云端API客户端集成")
    print("-" * 40)
    
    # 创建配置管理器和API客户端
    config_manager = ConfigManager()
    api_client = CloudAPIClient(config_manager)
    
    # 模拟风格预测结果
    style_prediction = {
        'prediction_type': 'Realistic Landscape',
        'confidence': 0.82,
        'style_recommendation': 'realistic photographic',
        'weather_influence': 'moderate conditions suggest clear details'
    }
    
    # 模拟天气数据
    weather_data = {
        'current_weather': {
            'temperature': 16,
            'humidity': 85,
            'pressure': 1008,
            'wind_speed': 6.1,
            'weather_main': 'Rain',
            'weather_description': 'light rain'
        }
    }
    
    # 模拟位置信息
    location_info = {
        'latitude': 55.9533,
        'longitude': -3.1883,
        'formatted_coords': '55.9533, -3.1883',
        'map_info': {
            'location_info': 'Edinburgh, Scotland, UK',
            'location_details': {
                'locality': 'Edinburgh',
                'country': 'Scotland'
            }
        }
    }
    
    try:
        # 测试prompt构建
        prompt = api_client._build_art_prompt(style_prediction, weather_data, location_info)
        print(f"✅ Prompt生成成功")
        print(f"长度: {len(prompt)} 字符")
        print(f"Content preview:")
        print(prompt[:300] + "..." if len(prompt) > 300 else prompt)
        
        # 测试备用prompt构建
        fallback_prompt = api_client._build_fallback_art_prompt(style_prediction, weather_data, location_info)
        print(f"\n✅ 备用Prompt生成成功")
        print(f"长度: {len(fallback_prompt)} 字符")
        print(f"Content: {fallback_prompt}")
        
    except Exception as e:
        print(f"❌ 集成测试失败: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n✅ 云端API客户端集成测试完成")

def test_multiple_scenarios():
    """测试多种场景"""
    print("\n🧪 测试3: 多种环境场景")
    print("-" * 40)
    
    builder = ImagePromptBuilder()
    
    scenarios = [
        {
            'name': '夏日晴朗',
            'weather': {
                'current_weather': {
                    'temperature': 28,
                    'humidity': 45,
                    'pressure': 1020,
                    'wind_speed': 2.1,
                    'weather_description': 'clear sky'
                }
            },
            'location': {
                'latitude': 40.7128,
                'longitude': -74.0060,
                'map_info': {
                    'location_info': 'New York City, NY, USA',
                    'location_details': {'locality': 'Manhattan', 'country': 'USA'}
                }
            }
        },
        {
            'name': '冬日雪景',
            'weather': {
                'current_weather': {
                    'temperature': -2,
                    'humidity': 90,
                    'pressure': 1005,
                    'wind_speed': 8.3,
                    'weather_description': 'snow'
                }
            },
            'location': {
                'latitude': 64.2008,
                'longitude': -149.4937,
                'map_info': {
                    'location_info': 'Fairbanks, Alaska, USA',
                    'location_details': {'locality': 'Fairbanks', 'country': 'USA'}
                }
            }
        },
        {
            'name': '热带雨林',
            'weather': {
                'current_weather': {
                    'temperature': 26,
                    'humidity': 95,
                    'pressure': 1010,
                    'wind_speed': 1.5,
                    'weather_description': 'thunderstorm'
                }
            },
            'location': {
                'latitude': -3.4653,
                'longitude': -62.2159,
                'map_info': {
                    'location_info': 'Amazon Rainforest, Brazil',
                    'location_details': {'locality': 'Amazon', 'country': 'Brazil'}
                }
            }
        }
    ]
    
    for scenario in scenarios:
        print(f"\n🌍 {scenario['name']}:")
        try:
            prompt = builder.build_comprehensive_prompt(
                weather_data=scenario['weather'],
                location_info=scenario['location'],
                style_preference='realistic'
            )
            print(f"  ✅ 生成成功 ({len(prompt)} 字符)")
            # 显示关键信息
            lines = prompt.split('\n')
            for line in lines:
                if 'Temperature:' in line or 'Weather:' in line or 'Address:' in line:
                    print(f"    {line.strip()}")
        except Exception as e:
            print(f"  ❌ 失败: {e}")
    
    print("\n✅ 多场景测试完成")

def main():
    """主测试函数"""
    print("🔭 Obscura No.7 - Prompt模板集成测试")
    print("=" * 60)
    
    try:
        # 测试1: 独立prompt构建器
        test_prompt_builder_standalone()
        
        # 测试2: API客户端集成
        test_cloud_api_client_integration()
        
        # 测试3: 多种场景
        test_multiple_scenarios()
        
        print("\n" + "=" * 60)
        print("🎉 所有测试完成！")
        print("\n📋 测试总结:")
        print("✅ Prompt模板构建器功能正常")
        print("✅ 云端API客户端集成成功")
        print("✅ 多种环境场景支持")
        print("✅ 基于1_1脚本的模板化prompt功能已成功集成")
        
    except Exception as e:
        print(f"\n❌ 测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code) 